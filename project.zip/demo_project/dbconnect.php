<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "userregistration2";

 	$conn = mysqli_connect($servername, $username, $password, $dbname);