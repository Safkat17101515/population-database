<?php

require_once('dbconnect.php');
if (isset($_POST['login'])) {
	
	session_start();

	
	$name = $_POST['name'];
	$user = $_POST['username'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	$passConfirm = $_POST['passConfirm'];


	$fahd = "select * from citizen where userid = '$user'";

	$resultfahd = mysqli_query($conn, $fahd);

	$numfahd = mysqli_num_rows($resultfahd);

	// user account validation

	$u = "select * from usertable where username = '$user' && password = '$pass'";

	$resultu = mysqli_query($conn, $u);

	$numu = mysqli_num_rows($resultu);

	//admin account validation

	$a = "select * from admin where username = '$user' && password = '$pass'";

	$resulta = mysqli_query($conn, $a);

	$numa = mysqli_num_rows($resulta);

	
	if($numu == 1){
		$_SESSION['uname'] = $user;
		if($numfahd == 1){
			header('location:home2.php');
			exit();
		}
		else{
	 	header('location:home.php');
	 	exit();
	 }
	}

	elseif ($numa == 1) {
		$_SESSION['uname'] = $user;
		header('location:adminhome.php');
	 	exit();
	}

	else{
		header('location:index.php?not_registered');
		exit();
	}
}
else{

	header("Location: index.php?error");
	exit();
}
?>